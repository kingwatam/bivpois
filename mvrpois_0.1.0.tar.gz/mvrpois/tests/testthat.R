library(testthat)
library(mvrpois)

test_check("mvrpois")
